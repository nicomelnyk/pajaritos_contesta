// Acuaticas option configuration
var REPLY_OPTION_ACUATICAS = {
  name: 'Acuaticas',
  replies: [
  {
    id: 'acuaticas_1',
    text: 'Toda la información relacionada a acuaticas la podés encontrar en el siguiente link. Como primer paso leelo con tranquilidad https://pajaros-caidos.blogspot.com/2010/01/primeros-auxilios-en-aves.html',
    image: null
  }
  ]
};

// Auto-register this option
(function() {
  if (typeof REPLY_OPTIONS_REGISTER === 'function') {
  REPLY_OPTIONS_REGISTER('acuaticas', REPLY_OPTION_ACUATICAS);
  }
})();

